import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// Foydalanuvchi ma'lumotlari telefonda saqlanadi (internet kerak emas).
class Store extends ChangeNotifier {
  Store._();
  static final Store i = Store._();

  late SharedPreferences _p;

  final ValueNotifier<ThemeMode> themeMode = ValueNotifier(ThemeMode.system);
  String name = 'Foydalanuvchi';
  int coins = 0;
  int quizzesPlayed = 0;
  Map<String, int> records = {};
  List<Word> savedWords = [];
  Set<String> savedVerbs = {};
  List<Word> myWords = [];
  List<Word> reviewWords = [];

  String get initial {
    final n = name.trim();
    return n.isEmpty ? '?' : n.substring(0, 1).toUpperCase();
  }

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    name = _p.getString('name') ?? name;
    final t = (_p.getInt('theme') ?? 0).clamp(0, 2).toInt();
    themeMode.value = ThemeMode.values[t];
    coins = _p.getInt('coins') ?? 0;
    quizzesPlayed = _p.getInt('played') ?? 0;
    try {
      final r = _p.getString('records');
      if (r != null) {
        records = (jsonDecode(r) as Map)
            .map((k, v) => MapEntry(k.toString(), (v as num).toInt()));
      }
    } catch (_) {}
    savedWords = _loadWords('saved');
    myWords = _loadWords('mine');
    reviewWords = _loadWords('review');
    savedVerbs = (_p.getStringList('savedVerbs') ?? []).toSet();
  }

  List<Word> _loadWords(String k) {
    try {
      return (_p.getStringList(k) ?? [])
          .map((s) => Word.fromJson(jsonDecode(s) as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  void _saveWords(String k, List<Word> l) {
    _p.setStringList(k, l.map((w) => jsonEncode(w.toJson())).toList());
  }

  // --- Saqlangan so'zlar ---
  bool isSaved(Word w) => savedWords.any((x) => x.key == w.key);

  void toggleSaved(Word w) {
    if (isSaved(w)) {
      savedWords.removeWhere((x) => x.key == w.key);
    } else {
      savedWords.insert(0, w);
    }
    _saveWords('saved', savedWords);
    notifyListeners();
  }

  // --- Saqlangan fe'llar ---
  bool isVerbSaved(Verb v) => savedVerbs.contains(v.base);

  void toggleVerb(Verb v) {
    if (!savedVerbs.remove(v.base)) savedVerbs.add(v.base);
    _p.setStringList('savedVerbs', savedVerbs.toList());
    notifyListeners();
  }

  // --- Mening so'zlarim ---
  bool addMyWord(Word w) {
    if (myWords.any((x) => x.key == w.key)) return false;
    myWords.insert(0, w);
    _saveWords('mine', myWords);
    notifyListeners();
    return true;
  }

  void removeMyWord(Word w) {
    myWords.removeWhere((x) => x.key == w.key);
    _saveWords('mine', myWords);
    notifyListeners();
  }

  // --- Takrorlash (xato qilingan so'zlar) ---
  void addReview(Word w) {
    if (reviewWords.any((x) => x.key == w.key)) return;
    reviewWords.add(w);
    _saveWords('review', reviewWords);
    notifyListeners();
  }

  void removeReview(Word w) {
    final before = reviewWords.length;
    reviewWords.removeWhere((x) => x.key == w.key);
    if (before != reviewWords.length) {
      _saveWords('review', reviewWords);
      notifyListeners();
    }
  }

  void clearReview() {
    reviewWords.clear();
    _saveWords('review', reviewWords);
    notifyListeners();
  }

  // --- Natijalar ---
  int record(String key) => records[key] ?? 0;

  /// Natijani saqlaydi. Yangi rekord bo'lsa true qaytaradi.
  bool saveResult(String key, int correct) {
    coins += correct * 5;
    quizzesPlayed++;
    final isNew = correct > record(key);
    if (isNew) records[key] = correct;
    _p.setInt('coins', coins);
    _p.setInt('played', quizzesPlayed);
    _p.setString('records', jsonEncode(records));
    notifyListeners();
    return isNew;
  }

  // --- Sozlamalar ---
  void setName(String n) {
    final v = n.trim();
    if (v.isEmpty) return;
    name = v;
    _p.setString('name', v);
    notifyListeners();
  }

  void setTheme(ThemeMode m) {
    themeMode.value = m;
    _p.setInt('theme', m.index);
  }

  void resetProgress() {
    coins = 0;
    quizzesPlayed = 0;
    records.clear();
    reviewWords.clear();
    _p.setInt('coins', 0);
    _p.setInt('played', 0);
    _p.setString('records', '{}');
    _saveWords('review', reviewWords);
    notifyListeners();
  }
}
