import 'package:flutter_tts/flutter_tts.dart';

/// Inglizcha so'zlarni ovoz chiqarib o'qiydi (telefonning o'z TTS dvigateli).
class Speaker {
  static final FlutterTts _tts = FlutterTts();
  static bool _ready = false;

  static Future<void> _init() async {
    if (_ready) return;
    _ready = true;
    try {
      await _tts.setLanguage('en-US');
      await _tts.awaitSpeakCompletion(true);
    } catch (_) {}
  }

  static Future<void> speak(String text, {bool slow = false}) async {
    await _init();
    try {
      await _tts.stop();
      await _tts.setSpeechRate(slow ? 0.2 : 0.45);
      await _tts.speak(text);
    } catch (_) {}
  }

  static Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
