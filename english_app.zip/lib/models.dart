/// JSON ro'yxatini Map ro'yxatiga aylantiradi.
List<Map<String, dynamic>> mapList(dynamic v) => v is List
    ? v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
    : <Map<String, dynamic>>[];

class Word {
  const Word({
    required this.en,
    required this.uz,
    this.type = '',
    this.example = '',
  });

  final String en;
  final String uz;
  final String type;
  final String example;

  factory Word.fromJson(Map<String, dynamic> j) => Word(
        en: (j['en'] ?? '').toString(),
        uz: (j['uz'] ?? '').toString(),
        type: (j['type'] ?? '').toString(),
        example: (j['example'] ?? '').toString(),
      );

  Map<String, dynamic> toJson() =>
      {'en': en, 'uz': uz, 'type': type, 'example': example};

  String get key => '${en.toLowerCase()}|${uz.toLowerCase()}';
}

class Unit {
  const Unit(this.title, this.words);
  final String title;
  final List<Word> words;

  factory Unit.fromJson(Map<String, dynamic> j) => Unit(
        (j['title'] ?? '').toString(),
        mapList(j['words']).map(Word.fromJson).toList(),
      );
}

class Book {
  const Book({
    required this.id,
    required this.title,
    required this.emoji,
    required this.units,
  });

  final String id;
  final String title;
  final String emoji;
  final List<Unit> units;

  List<Word> get words => [for (final u in units) ...u.words];

  factory Book.fromJson(Map<String, dynamic> j) => Book(
        id: (j['id'] ?? '').toString(),
        title: (j['title'] ?? '').toString(),
        emoji: (j['emoji'] ?? '📘').toString(),
        units: mapList(j['units']).map(Unit.fromJson).toList(),
      );
}

class Verb {
  const Verb({
    required this.uz,
    required this.base,
    required this.past,
    required this.pp,
  });

  final String uz;
  final String base;
  final String past;
  final String pp;

  factory Verb.fromJson(Map<String, dynamic> j) => Verb(
        uz: (j['uz'] ?? '').toString(),
        base: (j['base'] ?? '').toString(),
        past: (j['past'] ?? '').toString(),
        pp: (j['pp'] ?? '').toString(),
      );
}

class WordSource {
  const WordSource(this.title, this.words);
  final String title;
  final List<Word> words;
}
