import 'package:flutter/material.dart';

import 'models.dart';
import 'store.dart';
import 'tts.dart';

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;

Color cardColor(BuildContext c) =>
    isDark(c) ? const Color(0xFF1C2029) : Colors.white;

Future<T?> go<T>(BuildContext context, Widget page) =>
    Navigator.of(context).push<T>(MaterialPageRoute(builder: (_) => page));

String capitalize(String s) =>
    s.isEmpty ? s : s.substring(0, 1).toUpperCase() + s.substring(1);

class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.onTap,
    this.color,
    this.padding = const EdgeInsets.all(16),
    this.radius = 20,
  });

  final Widget child;
  final VoidCallback? onTap;
  final Color? color;
  final EdgeInsetsGeometry padding;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    return Material(
      color: color ?? cardColor(context),
      borderRadius: r,
      child: InkWell(
        borderRadius: r,
        onTap: onTap,
        child: Padding(padding: padding, child: child),
      ),
    );
  }
}

class SquareButton extends StatelessWidget {
  const SquareButton({super.key, required this.icon, this.onTap, this.color});

  final IconData icon;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      radius: 14,
      padding: const EdgeInsets.all(10),
      child: Icon(icon, size: 22, color: color),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 12),
      child: Text(
        text,
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class TypeChip extends StatelessWidget {
  const TypeChip(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    final c = Theme.of(context).colorScheme.primary;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: c.withAlpha(30),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: TextStyle(color: c, fontSize: 12)),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.emoji,
    required this.title,
    this.subtitle,
    this.action,
  });

  final String emoji;
  final String title;
  final String? subtitle;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 56)),
            const SizedBox(height: 12),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 8),
              Text(
                subtitle!,
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).hintColor),
              ),
            ],
            if (action != null) ...[const SizedBox(height: 16), action!],
          ],
        ),
      ),
    );
  }
}

class FeatureTile extends StatelessWidget {
  const FeatureTile({
    super.key,
    required this.title,
    required this.emoji,
    required this.color,
    required this.onTap,
    this.height = 120,
    this.emojiSize = 44,
  });

  final String title;
  final String emoji;
  final Color color;
  final VoidCallback onTap;
  final double height;
  final double emojiSize;

  @override
  Widget build(BuildContext context) {
    final bg = isDark(context)
        ? Color.alphaBlend(color.withAlpha(45), const Color(0xFF1C2029))
        : color;
    return AppCard(
      color: bg,
      onTap: onTap,
      radius: 22,
      padding: EdgeInsets.zero,
      child: SizedBox(
        height: height,
        child: Stack(
          children: [
            Positioned(
              left: 14,
              top: 12,
              right: 14,
              child: Text(
                title,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
            ),
            Positioned(
              right: 10,
              bottom: 6,
              child: Text(emoji, style: TextStyle(fontSize: emojiSize)),
            ),
          ],
        ),
      ),
    );
  }
}

/// So'z kartasi: inglizcha, tarjima, turi, misol, ovoz va saqlash tugmalari.
class WordCard extends StatefulWidget {
  const WordCard({super.key, required this.word, this.reversed = false});

  final Word word;
  final bool reversed;

  @override
  State<WordCard> createState() => _WordCardState();
}

class _WordCardState extends State<WordCard> {
  bool open = false;

  @override
  Widget build(BuildContext context) {
    final w = widget.word;
    final cs = Theme.of(context).colorScheme;
    final main = widget.reversed ? w.uz : w.en;
    final sub = widget.reversed ? w.en : w.uz;
    final hasExample = w.example.isNotEmpty;

    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: AppCard(
              onTap: hasExample ? () => setState(() => open = !open) : null,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          main,
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w700),
                        ),
                      ),
                      if (w.type.isNotEmpty) TypeChip(w.type),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(sub, style: TextStyle(color: cs.primary, fontSize: 16)),
                  if (hasExample && open) ...[
                    const SizedBox(height: 8),
                    Text(
                      '💬 ${w.example}',
                      style: TextStyle(
                        fontStyle: FontStyle.italic,
                        color: Theme.of(context).hintColor,
                      ),
                    ),
                  ],
                  if (hasExample)
                    Align(
                      alignment: Alignment.centerRight,
                      child: Icon(
                        open ? Icons.expand_less : Icons.expand_more,
                        size: 18,
                        color: Theme.of(context).hintColor,
                      ),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              SquareButton(
                icon: Icons.volume_up_rounded,
                onTap: () => Speaker.speak(w.en),
              ),
              const SizedBox(height: 8),
              ListenableBuilder(
                listenable: Store.i,
                builder: (context, child) {
                  final saved = Store.i.isSaved(w);
                  return SquareButton(
                    icon: saved ? Icons.bookmark : Icons.bookmark_border,
                    color: saved ? cs.primary : null,
                    onTap: () => Store.i.toggleSaved(w),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
