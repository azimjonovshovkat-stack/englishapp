import 'package:flutter/material.dart';

import 'data.dart';
import 'screens/bookmarks.dart';
import 'screens/home.dart';
import 'screens/profile.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Store.i.init();
  await AppData.load();
  runApp(const MyApp());
}

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: const Color(0xFF1677E5),
    brightness: b,
  ).copyWith(
    surface: dark ? const Color(0xFF111318) : const Color(0xFFF3F5F8),
  );
  return ThemeData(useMaterial3: true, colorScheme: scheme);
}

final ThemeData _light = buildTheme(Brightness.light);
final ThemeData _dark = buildTheme(Brightness.dark);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: Store.i.themeMode,
      builder: (context, mode, child) => MaterialApp(
        title: 'EngWords',
        debugShowCheckedModeBanner: false,
        themeMode: mode,
        theme: _light,
        darkTheme: _dark,
        home: const RootShell(),
      ),
    );
  }
}

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: tab,
        children: const [HomeScreen(), BookmarksScreen(), ProfileScreen()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Bosh sahifa',
          ),
          NavigationDestination(
            icon: Icon(Icons.bookmark_border),
            selectedIcon: Icon(Icons.bookmark),
            label: 'Saqlangan',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}
