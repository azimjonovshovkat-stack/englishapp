import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'models.dart';
import 'store.dart';

/// assets/ papkasidagi JSON fayllardan so'zlarni yuklaydi.
class AppData {
  static List<Book> books = [];
  static List<Verb> verbs = [];

  static Future<void> load() async {
    try {
      final raw = await rootBundle.loadString('assets/words.json');
      final map = jsonDecode(raw) as Map<String, dynamic>;
      books = mapList(map['books']).map(Book.fromJson).toList();
    } catch (e) {
      debugPrint("words.json o'qilmadi: $e");
    }
    try {
      final raw = await rootBundle.loadString('assets/irregular_verbs.json');
      verbs = mapList(jsonDecode(raw)).map(Verb.fromJson).toList();
    } catch (e) {
      debugPrint("irregular_verbs.json o'qilmadi: $e");
    }
  }

  static List<Word> get bookWords => [for (final b in books) ...b.words];

  static List<Word> get allWords => [...bookWords, ...Store.i.myWords];

  static List<WordSource> sources() => [
        for (final b in books) WordSource(b.title, b.words),
        WordSource("Mening so'zlarim", List.of(Store.i.myWords)),
        WordSource('Saqlanganlar', List.of(Store.i.savedWords)),
        WordSource('Takrorlash', List.of(Store.i.reviewWords)),
      ];
}
