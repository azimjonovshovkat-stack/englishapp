import 'package:flutter/material.dart';

import '../data.dart';
import '../models.dart';
import '../store.dart';
import '../tts.dart';
import '../widgets.dart';
import 'quiz.dart';

const baseColor = Color(0xFF43A047);
const pastColor = Color(0xFF1E88E5);
const ppColor = Color(0xFFE53935);

class VerbsScreen extends StatefulWidget {
  const VerbsScreen({super.key});

  @override
  State<VerbsScreen> createState() => _VerbsScreenState();
}

class _VerbsScreenState extends State<VerbsScreen> {
  String query = '';
  bool searching = false;
  bool onlySaved = false;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Store.i,
      builder: (context, child) {
        final list = AppData.verbs.where((v) {
          if (onlySaved && !Store.i.isVerbSaved(v)) return false;
          if (query.isEmpty) return true;
          return v.base.contains(query) ||
              v.past.contains(query) ||
              v.pp.contains(query) ||
              v.uz.toLowerCase().contains(query);
        }).toList();

        return Scaffold(
          appBar: AppBar(
            title: searching
                ? TextField(
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: "Fe'lni qidirish...",
                      border: InputBorder.none,
                    ),
                    onChanged: (v) =>
                        setState(() => query = v.trim().toLowerCase()),
                  )
                : const Text('Irregular Verbs'),
            actions: [
              IconButton(
                icon: Icon(searching ? Icons.close : Icons.search),
                onPressed: () => setState(() {
                  searching = !searching;
                  query = '';
                }),
              ),
              IconButton(
                icon: const Icon(Icons.quiz_outlined),
                tooltip: 'Test',
                onPressed: () => startVerbQuiz(context),
              ),
            ],
          ),
          body: Column(
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: VerbLegend(),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    ChoiceChip(
                      label: const Text('Hammasi'),
                      selected: !onlySaved,
                      onSelected: (_) => setState(() => onlySaved = false),
                    ),
                    const SizedBox(width: 8),
                    ChoiceChip(
                      label: const Text('Saqlanganlar'),
                      selected: onlySaved,
                      onSelected: (_) => setState(() => onlySaved = true),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: list.isEmpty
                    ? const EmptyState(
                        emoji: '🔍', title: 'Hech narsa topilmadi')
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: list.length,
                        itemBuilder: (context, i) => VerbCard(verb: list[i]),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class VerbLegend extends StatelessWidget {
  const VerbLegend({super.key});

  Widget _item(Color c, String t) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: c, shape: BoxShape.circle),
          ),
          const SizedBox(width: 6),
          Text(t, style: TextStyle(color: c, fontWeight: FontWeight.w600)),
        ],
      );

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 16,
      runSpacing: 6,
      children: [
        _item(baseColor, 'Base form'),
        _item(pastColor, 'Past simple'),
        _item(ppColor, 'Past participle'),
      ],
    );
  }
}

class VerbCard extends StatelessWidget {
  const VerbCard({super.key, required this.verb});
  final Verb verb;

  Widget _form(Color c, String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(color: c, shape: BoxShape.circle),
            ),
            const SizedBox(width: 10),
            Expanded(child: Text(t, style: const TextStyle(fontSize: 16))),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final saved = Store.i.isVerbSaved(verb);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    capitalize(verb.uz),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  _form(baseColor, verb.base),
                  _form(pastColor, verb.past),
                  _form(ppColor, verb.pp),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              SquareButton(
                icon: Icons.volume_up_rounded,
                onTap: () =>
                    Speaker.speak('${verb.base}, ${verb.past}, ${verb.pp}'),
              ),
              const SizedBox(height: 8),
              SquareButton(
                icon: saved ? Icons.bookmark : Icons.bookmark_border,
                color: saved ? Theme.of(context).colorScheme.primary : null,
                onTap: () => Store.i.toggleVerb(verb),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
