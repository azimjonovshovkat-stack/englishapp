import 'package:flutter/material.dart';

import '../data.dart';
import '../models.dart';
import '../store.dart';
import '../tts.dart';
import '../widgets.dart';

Future<void> showFlashcardSource(BuildContext context) =>
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text(
                "Qaysi so'zlarni takrorlaymiz?",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
              ),
            ),
            for (final s in AppData.sources())
              ListTile(
                title: Text(s.title),
                trailing: Text("${s.words.length} ta"),
                enabled: s.words.isNotEmpty,
                onTap: () {
                  Navigator.pop(ctx);
                  go(context, FlashcardsScreen(title: s.title, words: s.words));
                },
              ),
          ],
        ),
      ),
    );

class FlashcardsScreen extends StatefulWidget {
  const FlashcardsScreen({super.key, required this.title, required this.words});

  final String title;
  final List<Word> words;

  @override
  State<FlashcardsScreen> createState() => _FlashcardsScreenState();
}

class _FlashcardsScreenState extends State<FlashcardsScreen> {
  late final List<Word> cards = [...widget.words]..shuffle();
  final PageController ctrl = PageController();
  final Set<int> flipped = {};
  int page = 0;

  @override
  void dispose() {
    ctrl.dispose();
    Speaker.stop();
    super.dispose();
  }

  void _nextPage() {
    if (page < cards.length - 1) {
      ctrl.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('🎉 Barcha kartochkalar tugadi!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    if (cards.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: const EmptyState(emoji: '🃏', title: "Kartochka yo'q"),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Text('${page + 1}/${cards.length}',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: ctrl,
                itemCount: cards.length,
                onPageChanged: (p) => setState(() => page = p),
                itemBuilder: (context, i) {
                  final w = cards[i];
                  final f = flipped.contains(i);
                  final fg = f ? cs.onPrimary : null;
                  return Padding(
                    padding: const EdgeInsets.all(24),
                    child: GestureDetector(
                      onTap: () => setState(() {
                        if (f) {
                          flipped.remove(i);
                        } else {
                          flipped.add(i);
                        }
                      }),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 250),
                        decoration: BoxDecoration(
                          color: f ? cs.primary : cardColor(context),
                          borderRadius: BorderRadius.circular(28),
                        ),
                        child: Center(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  f ? w.uz : w.en,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.w800,
                                    color: fg,
                                  ),
                                ),
                                if (!f && w.type.isNotEmpty) ...[
                                  const SizedBox(height: 8),
                                  TypeChip(w.type),
                                ],
                                if (f && w.example.isNotEmpty) ...[
                                  const SizedBox(height: 16),
                                  Text(
                                    w.example,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontStyle: FontStyle.italic,
                                      color: fg,
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 24),
                                Text(
                                  f
                                      ? 'Qaytarish uchun bosing'
                                      : "Tarjimani ko'rish uchun bosing",
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: fg ?? Theme.of(context).hintColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Store.i.addReview(cards[page]);
                        _nextPage();
                      },
                      icon: const Icon(Icons.replay),
                      label: const Text('Bilmayman'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  IconButton.filledTonal(
                    onPressed: () => Speaker.speak(cards[page].en),
                    icon: const Icon(Icons.volume_up_rounded),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () {
                        Store.i.removeReview(cards[page]);
                        _nextPage();
                      },
                      icon: const Icon(Icons.check),
                      label: const Text('Bilaman'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
