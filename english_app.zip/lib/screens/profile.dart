import 'package:flutter/material.dart';

import '../store.dart';
import '../widgets.dart';

String _recordName(String key) {
  if (key == 'verbs') return 'Irregular Verbs';
  if (key.startsWith('quiz_')) return key.substring(5);
  return key;
}

Widget _stat(BuildContext context, String emoji, String value, String label) {
  return AppCard(
    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
    child: Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 22)),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        Text(label,
            style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
      ],
    ),
  );
}

Future<void> _rename(BuildContext context) async {
  final c = TextEditingController(text: Store.i.name);
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Ismingiz'),
      content: TextField(controller: c, autofocus: true),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Bekor qilish')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Saqlash')),
      ],
    ),
  );
  if (ok == true) Store.i.setName(c.text);
}

Future<void> _reset(BuildContext context) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Natijalarni tozalash'),
      content: const Text(
          "Tangalar, rekordlar va takrorlash ro'yxati o'chiriladi. Saqlangan va o'zingiz qo'shgan so'zlar qoladi."),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Bekor qilish')),
        FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Tozalash')),
      ],
    ),
  );
  if (ok == true) Store.i.resetProgress();
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Store.i,
      builder: (context, child) {
        final s = Store.i;
        const gap = SizedBox(width: 10);
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              const Text('Profil',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              AppCard(
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 32,
                      backgroundColor: Theme.of(context).colorScheme.primary,
                      child: Text(
                        s.initial,
                        style:
                            const TextStyle(fontSize: 26, color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Text(
                        s.name,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w700),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.edit_outlined),
                      tooltip: "Ismni o'zgartirish",
                      onPressed: () => _rename(context),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _stat(context, '🪙', '${s.coins}', 'Tanga')),
                  gap,
                  Expanded(
                      child: _stat(
                          context, '🎮', '${s.quizzesPlayed}', "O'yinlar")),
                  gap,
                  Expanded(
                    child: _stat(
                      context,
                      '🔖',
                      '${s.savedWords.length + s.savedVerbs.length}',
                      'Saqlangan',
                    ),
                  ),
                ],
              ),
              if (s.records.isNotEmpty) ...[
                const SectionTitle('🏆 Rekordlar'),
                AppCard(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Column(
                    children: [
                      for (final e in s.records.entries)
                        ListTile(
                          dense: true,
                          title: Text(_recordName(e.key)),
                          trailing: Text(
                            "${e.value} ta to'g'ri",
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
              const SectionTitle('Mavzu'),
              ValueListenableBuilder<ThemeMode>(
                valueListenable: s.themeMode,
                builder: (context, mode, child) => SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<ThemeMode>(
                    segments: const [
                      ButtonSegment(
                          value: ThemeMode.system, label: Text('Tizim')),
                      ButtonSegment(
                          value: ThemeMode.light, label: Text("Yorug'")),
                      ButtonSegment(
                          value: ThemeMode.dark, label: Text("Qorong'i")),
                    ],
                    selected: {mode},
                    onSelectionChanged: (v) => s.setTheme(v.first),
                  ),
                ),
              ),
              const SectionTitle('Boshqa'),
              AppCard(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    ListTile(
                      leading:
                          const Icon(Icons.restart_alt, color: Colors.red),
                      title: const Text('Natijalarni tozalash'),
                      onTap: () => _reset(context),
                    ),
                    const ListTile(
                      leading: Icon(Icons.info_outline),
                      title: Text('Ilova haqida'),
                      trailing: Text('v1.0.0'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
