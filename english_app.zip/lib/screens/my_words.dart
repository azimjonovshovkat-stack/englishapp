import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../widgets.dart';

class MyWordsScreen extends StatelessWidget {
  const MyWordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Store.i,
      builder: (context, child) {
        final words = Store.i.myWords;
        return Scaffold(
          appBar: AppBar(title: const Text("Mening so'zlarim")),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => addWordDialog(context),
            icon: const Icon(Icons.add),
            label: const Text("So'z qo'shish"),
          ),
          body: words.isEmpty
              ? const EmptyState(
                  emoji: '🗝️',
                  title: "Hali so'z qo'shilmagan",
                  subtitle:
                      "O'rganayotgan so'zlaringizni qo'shing. Ular testlarda ham chiqadi.",
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                  itemCount: words.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(
                          "O'chirish uchun chapga suring",
                          style: TextStyle(
                            fontSize: 13,
                            color: Theme.of(context).hintColor,
                          ),
                        ),
                      );
                    }
                    final w = words[i - 1];
                    return Dismissible(
                      key: ValueKey(w.key),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 24),
                        child: const Icon(Icons.delete, color: Colors.red),
                      ),
                      onDismissed: (_) => Store.i.removeMyWord(w),
                      child: WordCard(word: w),
                    );
                  },
                ),
        );
      },
    );
  }
}

Future<void> addWordDialog(BuildContext context) async {
  final en = TextEditingController();
  final uz = TextEditingController();
  final type = TextEditingController();
  final ex = TextEditingController();
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text("Yangi so'z"),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: en,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Inglizcha *'),
            ),
            TextField(
              controller: uz,
              decoration:
                  const InputDecoration(labelText: "O'zbekcha tarjimasi *"),
            ),
            TextField(
              controller: type,
              decoration: const InputDecoration(
                  labelText: "So'z turi (noun, verb, adj...)"),
            ),
            TextField(
              controller: ex,
              decoration: const InputDecoration(labelText: 'Misol gap'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('Bekor qilish'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('Saqlash'),
        ),
      ],
    ),
  );
  if (ok != true) return;
  if (en.text.trim().isEmpty || uz.text.trim().isEmpty) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Inglizcha so'z va tarjimani kiriting")));
    }
    return;
  }
  final added = Store.i.addMyWord(Word(
    en: en.text.trim(),
    uz: uz.text.trim(),
    type: type.text.trim(),
    example: ex.text.trim(),
  ));
  if (!added && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Bu so'z allaqachon qo'shilgan")));
  }
}
