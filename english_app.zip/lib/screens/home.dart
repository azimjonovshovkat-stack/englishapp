import 'package:flutter/material.dart';

import '../data.dart';
import '../store.dart';
import '../widgets.dart';
import 'books.dart';
import 'flashcards.dart';
import 'my_words.dart';
import 'quiz.dart';
import 'review.dart';
import 'verbs.dart';
import 'word_list.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Store.i,
      builder: (context, child) {
        final s = Store.i;
        const gap = SizedBox(width: 12);
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
            children: [
              Row(
                children: [
                  CircleAvatar(
                    radius: 24,
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    child: Text(
                      s.initial,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Salom, ${s.name} 👋',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w700),
                        ),
                        Text(
                          "Bugun nimani o'rganamiz?",
                          style: TextStyle(color: Theme.of(context).hintColor),
                        ),
                      ],
                    ),
                  ),
                  AppCard(
                    radius: 14,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Text(
                      '🪙 ${s.coins}',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
              const SectionTitle("O'yinlar"),
              Row(
                children: [
                  Expanded(
                    child: FeatureTile(
                      title: 'Test',
                      emoji: '📝',
                      color: const Color(0xFFFFF1D6),
                      onTap: () => showQuizSetup(context),
                    ),
                  ),
                  gap,
                  Expanded(
                    child: FeatureTile(
                      title: 'Irregular\nVerbs',
                      emoji: '🔁',
                      color: const Color(0xFFDDF3E8),
                      onTap: () => startVerbQuiz(context),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              FeatureTile(
                title: 'Kartochkalar',
                emoji: '🃏',
                color: const Color(0xFFE6E4FB),
                height: 90,
                onTap: () => showFlashcardSource(context),
              ),
              const SectionTitle("Lug'at"),
              Row(
                children: [
                  Expanded(
                    child: FeatureTile(
                      title: "Umumiy\nlug'at",
                      emoji: '📖',
                      emojiSize: 34,
                      color: const Color(0xFFE3EEFC),
                      onTap: () => go(
                        context,
                        WordListScreen(
                          title: "Lug'at",
                          words: AppData.allWords,
                          showFilters: true,
                        ),
                      ),
                    ),
                  ),
                  gap,
                  Expanded(
                    child: FeatureTile(
                      title: "To'plam-\nlar",
                      emoji: '📚',
                      emojiSize: 34,
                      color: const Color(0xFFFCE4E4),
                      onTap: () => go(context, const BooksScreen()),
                    ),
                  ),
                  gap,
                  Expanded(
                    child: FeatureTile(
                      title: "Fe'llar\n(3 shakl)",
                      emoji: '🌊',
                      emojiSize: 34,
                      color: const Color(0xFFDFF4F7),
                      onTap: () => go(context, const VerbsScreen()),
                    ),
                  ),
                ],
              ),
              const SectionTitle("Mening lug'atim"),
              Row(
                children: [
                  Expanded(
                    child: FeatureTile(
                      title: "Mening\nso'zlarim (${s.myWords.length})",
                      emoji: '🗝️',
                      emojiSize: 38,
                      color: const Color(0xFFFFF4E0),
                      onTap: () => go(context, const MyWordsScreen()),
                    ),
                  ),
                  gap,
                  Expanded(
                    child: FeatureTile(
                      title: 'Takrorlash\n(${s.reviewWords.length})',
                      emoji: '⏳',
                      emojiSize: 38,
                      color: const Color(0xFFEDE7F6),
                      onTap: () => go(context, const ReviewScreen()),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
