import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../data.dart';
import '../models.dart';
import '../store.dart';
import '../tts.dart';
import '../widgets.dart';

final _rnd = Random();

class Question {
  const Question({
    required this.prompt,
    required this.label,
    required this.options,
    required this.answer,
    this.speak,
    this.listening = false,
    this.word,
  });

  final String prompt;
  final String label;
  final List<String> options;
  final int answer;
  final String? speak;
  final bool listening;
  final Word? word;
}

List<Question> buildWordQuestions(
  List<Word> pool, {
  required int count,
  required bool enToUz,
  required bool listening,
}) {
  final unique = <String, Word>{};
  for (final w in pool) {
    unique[w.key] = w;
  }
  final words = unique.values.toList()..shuffle(_rnd);
  return words.take(count).map((w) {
    final correct = enToUz ? w.uz : w.en;
    final others = words
        .where((x) => x.key != w.key)
        .map((x) => enToUz ? x.uz : x.en)
        .where((s) => s != correct)
        .toSet()
        .toList()
      ..shuffle(_rnd);
    final opts = [correct, ...others.take(3)]..shuffle(_rnd);
    final listen = listening && enToUz;
    return Question(
      prompt: enToUz ? w.en : w.uz,
      label: listen
          ? 'Tinglang va tarjimasini tanlang'
          : (enToUz ? 'Tarjimasini toping' : 'Inglizchasini toping'),
      speak: enToUz ? w.en : null,
      listening: listen,
      options: opts,
      answer: opts.indexOf(correct),
      word: w,
    );
  }).toList();
}

List<Question> buildVerbQuestions(List<Verb> verbs, {int count = 20}) {
  final list = [...verbs]..shuffle(_rnd);
  return list.take(count).map((v) {
    final askPast = _rnd.nextBool();
    final correct = askPast ? v.past : v.pp;
    final others = verbs
        .map((x) => askPast ? x.past : x.pp)
        .where((s) => s != correct)
        .toSet()
        .toList()
      ..shuffle(_rnd);
    final opts = [correct, ...others.take(3)]..shuffle(_rnd);
    return Question(
      prompt: '${capitalize(v.uz)}\n(${v.base})',
      label: askPast
          ? 'Past Simple shaklini toping'
          : 'Past Participle shaklini toping',
      speak: v.base,
      options: opts,
      answer: opts.indexOf(correct),
    );
  }).toList();
}

void startVerbQuiz(BuildContext context) {
  if (AppData.verbs.length < 4) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Fe'llar ro'yxati topilmadi")),
    );
    return;
  }
  go(
    context,
    QuizScreen(
      title: 'Irregular Verbs',
      recordKey: 'verbs',
      builder: () => buildVerbQuestions(AppData.verbs),
    ),
  );
}

Future<void> showQuizSetup(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => const QuizSetupSheet(),
    );

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(
          text,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
        ),
      );
}

class QuizSetupSheet extends StatefulWidget {
  const QuizSetupSheet({super.key});

  @override
  State<QuizSetupSheet> createState() => _QuizSetupSheetState();
}

class _QuizSetupSheetState extends State<QuizSetupSheet> {
  late final List<WordSource> sources = AppData.sources();
  int src = 0;
  final Set<int> units = {};
  bool enToUz = true;
  bool listening = false;
  int count = 20;

  bool get isBook => src < AppData.books.length;

  List<Word> get pool {
    if (isBook && units.isNotEmpty) {
      final b = AppData.books[src];
      return [for (final u in units) ...b.units[u].words];
    }
    return sources[src].words;
  }

  void _start() {
    final p = pool;
    final title = sources[src].title;
    final e = enToUz;
    final l = listening && enToUz;
    final c = count;
    final nav = Navigator.of(context);
    nav.pop();
    nav.push(MaterialPageRoute(
      builder: (_) => QuizScreen(
        title: title,
        recordKey: 'quiz_$title',
        builder: () =>
            buildWordQuestions(p, count: c, enToUz: e, listening: l),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final canStart = pool.length >= 4;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Test sozlamalari',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 16),
            const _Label("So'zlar manbasi"),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (var i = 0; i < sources.length; i++)
                  ChoiceChip(
                    label: Text(
                        '${sources[i].title} (${sources[i].words.length})'),
                    selected: src == i,
                    onSelected: (_) => setState(() {
                      src = i;
                      units.clear();
                    }),
                  ),
              ],
            ),
            if (isBook && AppData.books[src].units.isNotEmpty) ...[
              const SizedBox(height: 16),
              const _Label('Unitlar (tanlanmasa, hammasi olinadi)'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var j = 0; j < AppData.books[src].units.length; j++)
                    FilterChip(
                      label: Text(AppData.books[src].units[j].title),
                      selected: units.contains(j),
                      onSelected: (v) => setState(() {
                        if (v) {
                          units.add(j);
                        } else {
                          units.remove(j);
                        }
                      }),
                    ),
                ],
              ),
            ],
            const SizedBox(height: 16),
            const _Label("Yo'nalish"),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('EN → UZ')),
                  ButtonSegment(value: false, label: Text('UZ → EN')),
                ],
                selected: {enToUz},
                onSelectionChanged: (s) => setState(() => enToUz = s.first),
              ),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tinglab topish'),
              subtitle: const Text("So'z yozilmaydi, faqat ovozi eshittiriladi"),
              value: listening && enToUz,
              onChanged: enToUz ? (v) => setState(() => listening = v) : null,
            ),
            const _Label('Savollar soni'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 10, label: Text('10')),
                  ButtonSegment(value: 20, label: Text('20')),
                  ButtonSegment(value: 30, label: Text('30')),
                ],
                selected: {count},
                onSelectionChanged: (s) => setState(() => count = s.first),
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: canStart ? _start : null,
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: Text(canStart ? 'Boshlash' : "Kamida 4 ta so'z kerak"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({
    super.key,
    required this.title,
    required this.recordKey,
    required this.builder,
  });

  final String title;
  final String recordKey;
  final List<Question> Function() builder;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  static const perQuestion = 20;
  static const letters = ['A', 'B', 'C', 'D'];
  static const letterColors = [
    Color(0xFF43A047),
    Color(0xFFFFB300),
    Color(0xFF1E88E5),
    Color(0xFFE53935),
  ];

  late final List<Question> questions;
  int index = 0;
  int correct = 0;
  int lives = 3;
  int seconds = perQuestion;
  int? selected;
  Set<int> hidden = {};
  bool used5050 = false;
  bool finished = false;
  Timer? timer;

  Question get q => questions[index];

  @override
  void initState() {
    super.initState();
    questions = widget.builder();
    if (questions.isNotEmpty) _startQuestion();
  }

  @override
  void dispose() {
    timer?.cancel();
    Speaker.stop();
    super.dispose();
  }

  void _startQuestion() {
    timer?.cancel();
    selected = null;
    hidden = {};
    seconds = perQuestion;
    if (q.listening && q.speak != null) Speaker.speak(q.speak!);
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() => seconds--);
      if (seconds <= 0) {
        t.cancel();
        _answer(-1);
      }
    });
  }

  void _answer(int i) {
    if (selected != null) return;
    timer?.cancel();
    setState(() => selected = i);
    final w = q.word;
    if (i == q.answer) {
      correct++;
      if (w != null) Store.i.removeReview(w);
    } else {
      lives--;
      if (w != null) Store.i.addReview(w);
    }
    Future.delayed(const Duration(milliseconds: 1100), _next);
  }

  void _next() {
    if (!mounted) return;
    if (lives <= 0 || index >= questions.length - 1) {
      _finish();
      return;
    }
    setState(() => index++);
    _startQuestion();
  }

  void _skip() {
    if (selected != null) return;
    timer?.cancel();
    _next();
  }

  void _fiftyFifty() {
    if (used5050 || selected != null) return;
    final wrong = [
      for (var i = 0; i < q.options.length; i++)
        if (i != q.answer) i
    ]..shuffle(_rnd);
    setState(() {
      used5050 = true;
      hidden = wrong.take(max(0, q.options.length - 2)).toSet();
    });
  }

  void _finish() {
    if (finished) return;
    finished = true;
    timer?.cancel();
    final isRecord = Store.i.saveResult(widget.recordKey, correct);
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => ResultScreen(
        correct: correct,
        total: questions.length,
        isRecord: isRecord,
        retry: () => QuizScreen(
          title: widget.title,
          recordKey: widget.recordKey,
          builder: widget.builder,
        ),
      ),
    ));
  }

  Widget _option(int i) {
    Color? bg;
    if (selected != null) {
      if (i == q.answer) {
        bg = Color.alphaBlend(Colors.green.withAlpha(70), cardColor(context));
      } else if (i == selected) {
        bg = Color.alphaBlend(Colors.red.withAlpha(70), cardColor(context));
      }
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        color: bg,
        onTap: selected == null ? () => _answer(i) : null,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: letterColors[i].withAlpha(45),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                letters[i],
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Text(q.options[i], style: const TextStyle(fontSize: 17)),
            ),
            if (selected != null && i == q.answer)
              const Icon(Icons.check_circle, color: Colors.green),
            if (selected != null && i == selected && i != q.answer)
              const Icon(Icons.cancel, color: Colors.red),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: const EmptyState(emoji: '🤷', title: "Savollar uchun so'z yetarli emas"),
      );
    }
    final hint = Theme.of(context).hintColor;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Row(
              children: [
                Text('✅ $correct',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(width: 12),
                const Icon(Icons.favorite, color: Colors.red),
                Text(' $lives',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: seconds / perQuestion,
                  minHeight: 8,
                  color: seconds <= 5 ? Colors.red : null,
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Text('Savol ${index + 1}/${questions.length}',
                      style: TextStyle(color: hint)),
                  const Spacer(),
                  Text('⏱ $seconds s', style: TextStyle(color: hint)),
                ],
              ),
              const SizedBox(height: 12),
              AppCard(
                child: SizedBox(
                  width: double.infinity,
                  child: Column(
                    children: [
                      Text(q.label, style: TextStyle(color: hint)),
                      const SizedBox(height: 12),
                      if (q.listening && selected == null) ...[
                        IconButton.filled(
                          iconSize: 40,
                          onPressed: () => Speaker.speak(q.speak!),
                          icon: const Icon(Icons.volume_up_rounded),
                        ),
                        TextButton(
                          onPressed: () => Speaker.speak(q.speak!, slow: true),
                          child: const Text('🐢 Sekinroq'),
                        ),
                      ] else ...[
                        Text(
                          q.prompt,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 28, fontWeight: FontWeight.w800),
                        ),
                        if (q.speak != null)
                          IconButton(
                            onPressed: () => Speaker.speak(q.speak!),
                            icon: const Icon(Icons.volume_up_rounded),
                          ),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView(
                  children: [
                    for (var i = 0; i < q.options.length; i++)
                      if (!hidden.contains(i)) _option(i),
                  ],
                ),
              ),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed:
                          used5050 || selected != null ? null : _fiftyFifty,
                      icon: const Icon(Icons.exposure_minus_2),
                      label: const Text('50/50'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: selected != null ? null : _skip,
                      icon: const Icon(Icons.skip_next),
                      label: const Text("O'tkazish"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.correct,
    required this.total,
    required this.isRecord,
    required this.retry,
  });

  final int correct;
  final int total;
  final bool isRecord;
  final Widget Function() retry;

  @override
  Widget build(BuildContext context) {
    final ratio = total == 0 ? 0.0 : correct / total;
    final emoji = ratio >= 0.9
        ? '🏆'
        : ratio >= 0.6
            ? '🎉'
            : ratio >= 0.3
                ? '👍'
                : '💪';
    final msg = ratio >= 0.9
        ? 'Ajoyib natija!'
        : ratio >= 0.6
            ? "Zo'r, davom eting!"
            : ratio >= 0.3
                ? 'Yomon emas'
                : "Yana bir urinib ko'ring";
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(emoji, style: const TextStyle(fontSize: 80)),
                const SizedBox(height: 12),
                Text(msg,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 26, fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text("$correct / $total to'g'ri javob",
                    style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 8),
                Text(
                  '+${correct * 5} 🪙',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
                if (isRecord) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.amber.withAlpha(60),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text('🏅 Yangi rekord!',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ],
                const SizedBox(height: 32),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: () => Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (_) => retry()),
                    ),
                    icon: const Icon(Icons.replay),
                    label: const Text("Qayta o'ynash"),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Orqaga'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
