import 'package:flutter/material.dart';

import '../data.dart';
import '../models.dart';
import '../widgets.dart';
import 'quiz.dart';
import 'word_list.dart';

class BooksScreen extends StatelessWidget {
  const BooksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final books = AppData.books;
    return Scaffold(
      appBar: AppBar(title: const Text("To'plamlar")),
      body: books.isEmpty
          ? const EmptyState(
              emoji: '📚',
              title: "To'plamlar topilmadi",
              subtitle: "assets/words.json fayliga so'zlar qo'shing",
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: books.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final b = books[i];
                return AppCard(
                  onTap: () => go(context, UnitsScreen(book: b)),
                  child: Row(
                    children: [
                      Text(b.emoji, style: const TextStyle(fontSize: 36)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              b.title,
                              style: const TextStyle(
                                  fontSize: 17, fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "${b.units.length} ta unit, ${b.words.length} ta so'z",
                              style:
                                  TextStyle(color: Theme.of(context).hintColor),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_right),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

class UnitsScreen extends StatelessWidget {
  const UnitsScreen({super.key, required this.book});
  final Book book;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(book.title),
        actions: [
          if (book.words.length >= 4)
            IconButton(
              icon: const Icon(Icons.quiz_outlined),
              tooltip: "Butun to'plamdan test",
              onPressed: () => go(
                context,
                QuizScreen(
                  title: book.title,
                  recordKey: 'quiz_${book.title}',
                  builder: () => buildWordQuestions(
                    book.words,
                    count: 20,
                    enToUz: true,
                    listening: false,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: book.units.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, i) {
          final u = book.units[i];
          final cs = Theme.of(context).colorScheme;
          return AppCard(
            onTap: () => go(
              context,
              WordListScreen(title: u.title, words: u.words),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: cs.primary.withAlpha(30),
                  child: Text(
                    '${i + 1}',
                    style: TextStyle(
                        color: cs.primary, fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        u.title,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w700),
                      ),
                      Text(
                        "${u.words.length} ta so'z",
                        style: TextStyle(color: Theme.of(context).hintColor),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
          );
        },
      ),
    );
  }
}
