import 'package:flutter/material.dart';

import '../data.dart';
import '../store.dart';
import '../widgets.dart';
import 'verbs.dart';

class BookmarksScreen extends StatefulWidget {
  const BookmarksScreen({super.key});

  @override
  State<BookmarksScreen> createState() => _BookmarksScreenState();
}

class _BookmarksScreenState extends State<BookmarksScreen> {
  int seg = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Text(
              'Saqlanganlar',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SizedBox(
              width: double.infinity,
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text("So'zlar")),
                  ButtonSegment(value: 1, label: Text("Fe'llar")),
                ],
                selected: {seg},
                onSelectionChanged: (s) => setState(() => seg = s.first),
              ),
            ),
          ),
          Expanded(
            child: ListenableBuilder(
              listenable: Store.i,
              builder: (context, child) {
                if (seg == 0) {
                  final words = Store.i.savedWords;
                  if (words.isEmpty) {
                    return const EmptyState(
                      emoji: '🔖',
                      title: "Saqlangan so'z yo'q",
                      subtitle: "So'z yonidagi 🔖 tugmasini bosing",
                    );
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: words.length,
                    itemBuilder: (context, i) => WordCard(word: words[i]),
                  );
                }
                final verbs = AppData.verbs.where(Store.i.isVerbSaved).toList();
                if (verbs.isEmpty) {
                  return const EmptyState(
                    emoji: '🔖',
                    title: "Saqlangan fe'l yo'q",
                    subtitle: "Irregular Verbs bo'limida 🔖 tugmasini bosing",
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: verbs.length,
                  itemBuilder: (context, i) => VerbCard(verb: verbs[i]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
