import 'package:flutter/material.dart';

import '../models.dart';
import '../tts.dart';
import '../widgets.dart';

/// Umumiy so'zlar ro'yxati: qidiruv, EN/UZ almashtirish, turlar bo'yicha filtr,
/// hammasini ketma-ket tinglash.
class WordListScreen extends StatefulWidget {
  const WordListScreen({
    super.key,
    required this.title,
    required this.words,
    this.showFilters = false,
  });

  final String title;
  final List<Word> words;
  final bool showFilters;

  @override
  State<WordListScreen> createState() => _WordListScreenState();
}

class _WordListScreenState extends State<WordListScreen> {
  String query = '';
  bool searching = false;
  bool reversed = false;
  String type = '';
  bool playing = false;

  late final List<String> types = widget.words
      .map((w) => w.type)
      .where((t) => t.isNotEmpty)
      .toSet()
      .toList()
    ..sort();

  List<Word> get filtered => widget.words.where((w) {
        if (type.isNotEmpty && w.type != type) return false;
        if (query.isEmpty) return true;
        return w.en.toLowerCase().contains(query) ||
            w.uz.toLowerCase().contains(query);
      }).toList();

  @override
  void dispose() {
    playing = false;
    Speaker.stop();
    super.dispose();
  }

  Future<void> _togglePlay() async {
    if (playing) {
      setState(() => playing = false);
      await Speaker.stop();
      return;
    }
    setState(() => playing = true);
    for (final w in filtered) {
      if (!mounted || !playing) break;
      await Speaker.speak(w.en);
      await Future.delayed(const Duration(milliseconds: 600));
    }
    if (mounted) setState(() => playing = false);
  }

  Widget _chip(String label, String value) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          label: Text(label),
          selected: type == value,
          onSelected: (_) => setState(() => type = value),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final list = filtered;
    return Scaffold(
      appBar: AppBar(
        title: searching
            ? TextField(
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: 'Qidirish...',
                  border: InputBorder.none,
                ),
                onChanged: (v) =>
                    setState(() => query = v.trim().toLowerCase()),
              )
            : Text(widget.title),
        actions: [
          IconButton(
            icon: Icon(searching ? Icons.close : Icons.search),
            onPressed: () => setState(() {
              searching = !searching;
              query = '';
            }),
          ),
          IconButton(
            icon: const Icon(Icons.swap_horiz),
            tooltip: 'EN ⇄ UZ',
            onPressed: () => setState(() => reversed = !reversed),
          ),
          IconButton(
            icon: Icon(playing
                ? Icons.stop_circle_outlined
                : Icons.play_circle_outline),
            tooltip: 'Hammasini tinglash',
            onPressed: list.isEmpty ? null : _togglePlay,
          ),
        ],
      ),
      body: Column(
        children: [
          if (widget.showFilters && types.length > 1)
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                children: [
                  _chip('Hammasi', ''),
                  for (final t in types) _chip(t, t),
                ],
              ),
            ),
          Expanded(
            child: list.isEmpty
                ? const EmptyState(emoji: '🔍', title: 'Hech narsa topilmadi')
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: list.length,
                    itemBuilder: (context, i) =>
                        WordCard(word: list[i], reversed: reversed),
                  ),
          ),
        ],
      ),
    );
  }
}
