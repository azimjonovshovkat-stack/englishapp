import 'package:flutter/material.dart';

import '../store.dart';
import '../widgets.dart';
import 'flashcards.dart';
import 'quiz.dart';

class ReviewScreen extends StatelessWidget {
  const ReviewScreen({super.key});

  Future<void> _confirmClear(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text("Ro'yxatni tozalash"),
        content: const Text("Takrorlash ro'yxatidagi barcha so'zlar o'chiriladi."),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Bekor qilish')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Tozalash')),
        ],
      ),
    );
    if (ok == true) Store.i.clearReview();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Store.i,
      builder: (context, child) {
        final words = Store.i.reviewWords;
        return Scaffold(
          appBar: AppBar(
            title: const Text('Takrorlash'),
            actions: [
              if (words.isNotEmpty)
                IconButton(
                  icon: const Icon(Icons.delete_sweep_outlined),
                  tooltip: 'Tozalash',
                  onPressed: () => _confirmClear(context),
                ),
            ],
          ),
          body: words.isEmpty
              ? const EmptyState(
                  emoji: '🎉',
                  title: "Takrorlash uchun so'z yo'q",
                  subtitle:
                      "Testda xato qilgan yoki kartochkada «Bilmayman» degan so'zlaringiz shu yerda chiqadi.",
                )
              : Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                      child: Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: words.length < 4
                                  ? null
                                  : () => go(
                                        context,
                                        QuizScreen(
                                          title: 'Takrorlash',
                                          recordKey: 'quiz_Takrorlash',
                                          builder: () => buildWordQuestions(
                                            List.of(Store.i.reviewWords),
                                            count: 20,
                                            enToUz: true,
                                            listening: false,
                                          ),
                                        ),
                                      ),
                              icon: const Icon(Icons.quiz_outlined),
                              label: const Text('Test'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () => go(
                                context,
                                FlashcardsScreen(
                                  title: 'Takrorlash',
                                  words: List.of(words),
                                ),
                              ),
                              icon: const Icon(Icons.style_outlined),
                              label: const Text('Kartochkalar'),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: words.length,
                        itemBuilder: (context, i) => WordCard(word: words[i]),
                      ),
                    ),
                  ],
                ),
        );
      },
    );
  }
}
