# EngWords — ingliz tili so'zlari ilovasi (Flutter)

## Imkoniyatlar
- To'plamlar va unitlar bo'yicha so'zlar, qidiruv, EN ⇄ UZ almashtirish
- Har bir so'zni ovoz chiqarib o'qish (telefon TTS), hammasini ketma-ket tinglash
- Test: vaqt (20 s), 3 ta jon, 50/50, o'tkazib yuborish, tinglab topish rejimi, rekordlar
- Irregular verbs ro'yxati va testi (71 ta fe'l)
- Kartochkalar (flashcards): Bilaman / Bilmayman
- Takrorlash: xato qilingan so'zlar avtomatik yig'iladi
- Mening so'zlarim: o'z so'zlaringizni qo'shish
- Saqlanganlar, profil, tanga, yorug'/qorong'i mavzu
- Hammasi internetsiz ishlaydi, ma'lumotlar telefonda saqlanadi

## So'z qo'shish
`assets/words.json` faylini tahrirlang. Tuzilishi:
```json
{"books": [{"id": "b1", "title": "To'plam nomi", "emoji": "📘",
  "units": [{"title": "Unit 1", "words": [
    {"en": "apple", "uz": "olma", "type": "noun", "example": "I like apples."}
  ]}]}]}
```

## APK olish — A yo'l: faqat telefon orqali (GitHub)
1. github.com da ro'yxatdan o'ting, yangi repository yarating (Public yoki Private).
2. "Add file → Upload files" orqali `english_app.zip` faylini yuklang, "Commit changes".
3. "Add file → Create new file". Nomiga aynan `.github/workflows/build.yml` yozing,
   ichiga `build.yml` faylining matnini nusxalab qo'ying, "Commit changes".
4. "Actions" bo'limida yig'ish boshlanadi (~8-12 daqiqa). Yashil ✅ chiqsa tayyor.
5. Repository sahifasidagi "Releases" bo'limidan `app-release.apk` ni yuklab oling.
6. Telefonda faylni oching, "Noma'lum manbalardan o'rnatish"ga ruxsat bering.

## APK olish — B yo'l: kompyuter orqali
```
flutter create . --platforms=android --project-name english_app
flutter pub get
flutter build apk --release
```
APK: `build/app/outputs/flutter-apk/app-release.apk`
